#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    int *x[4];
    int a=10,b=20,c=30,d=40,i;

    x[0]=&a;
    x[1]=&b;
    x[2]=&c;
    x[3]=&d;

    for(i=0; i<4; i++)
    {
        cout<<"Value of x["<<i<<"] = "<<x[i]<<" and Points to = "<<*x[i]<<endl;
    }
    return 0;
}
