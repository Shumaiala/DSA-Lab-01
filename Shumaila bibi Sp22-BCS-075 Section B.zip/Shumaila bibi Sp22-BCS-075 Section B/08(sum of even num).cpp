#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    int i,n,s,d,*x,*nm,*sum,*dg;
    x=&i;
    nm=&n;
    sum=&s;
    dg=&d;
    *sum=0;

    cout<<"Enter a number ";
    cin>>*nm;

    while(*nm>0)
    {
        *dg=*nm%10;
        if(*dg % 2==0)
        {
            *sum=*sum+*dg;
        }
        *nm=*nm/10;
    }

    cout<<"Sum of even digits = "<<*sum;
    return 0;
}
