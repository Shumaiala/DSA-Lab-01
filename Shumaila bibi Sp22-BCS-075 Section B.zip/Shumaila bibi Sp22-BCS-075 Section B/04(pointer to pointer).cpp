#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    int a=5,*b,**c;

    b=&a;      // store the address of variable a
    c=&b;      // store the address of variable b

    cout<<"Value of a = "<<a<<endl;

    cout<<"Address of a = "<<a<<endl;
    cout<<"Address of b = "<<&b<<endl;
    cout<<"Address of c = "<<&c<<endl;

    cout<<"b points to address = "<<b<<endl;
    cout<<"b points to value = "<<*b<<endl;

    cout<<"c points to address = "<<c<<endl;
    cout<<"c indirectly points to value "<<**c;
    return 0;
}
