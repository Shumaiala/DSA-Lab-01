#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    int a=5, *x;
    x=&a;

    cout<<"Value of a = "<<a<<endl;
    cout<<"Address of a = "<<&a<<endl;
    cout<<"Address of x = "<<&x<<endl;
    cout<<"x points to address = "<<x<<endl;
    cout<<"x points to value = "<<*x;
    return 0;
}
