#include <bits/stdc++.h>
#include <string>
using namespace std;
struct node {
   int data;
   struct node *next;
};
struct node *head = NULL;
struct node *current = NULL;

void printList(){
   struct node *p = head;
   cout << "\n[";
   
   while(p != NULL) {
      cout << " " << p->data << " ";
      p = p->next;
   }
   cout << "]";
}

void insertatbegin(int data){
   
   struct node *lk = (struct node*) malloc(sizeof (struct node));
   lk->data = data;
   
   lk->next = head;
   
   head = lk;
}
int main(){
   insertatbegin(50);
   insertatbegin(40);
   insertatbegin(30);
   insertatbegin(20);
   insertatbegin(10);
   cout << "Linked List: ";
   
   printList();
} 
#include <iostream>
using namespace std;
  
struct Node {
   int data;
   struct node* next;
   struct node* prev;
};
  
void insert_front(struct node** head, int new_data)
{

   struct node* newnode = new node;
  
   newnode->data = new_data;
   newnode->next = (*head);
   newnode->prev = NULL;
  
   if ((*head) != NULL)
   (*head)->prev = newnode;
   
   (*head) = newnode;
}
void insert_After(struct node* prev_node, int new_data)
{
   if (prev_node == NULL) {
   cout<<"Previous node is required , it cannot be NULL";
   return;
}
   struct Node* newnode = new Node;
  
   newnode->data = new_data;
   newnode->next = prev_node->next;
   prev_node->next = newnode;
   newnode->prev = prev_node;
   if (newnode->next != NULL)
   newnode->next->prev = newnode;
}
void insert_end(struct node** head, int new_data)
{
   struct Node* newnode = new node;
  
   struct node* last = *head;
   newnode->data = new_data;
   newnode->next = NULL;
   if (*head == NULL) {
   newnode->prev = NULL;
   *head = newnode;
    return;
}
while (last->next != NULL)
last = last->next;
last->next = newnode;
newnode->prev = last;
return;
}
void displayList(struct node* node) {
   struct node* last;
  
   while (node != NULL) {
      cout<<node->data<<"<==>";
      last = node;
      node = node->next;
   }
   if(node == NULL)
   cout<<"NULL";
   }
  
	
   struct node* head = NULL;
   insert_end(&head, 400);
   insert_front(&head, 200);
   insert_front(&head, 100);
   insert_end(&head, 500);
   insert_After(head->next, 300);
  
   cout<<"Doubly linked list is as follows: "<<endl;
   displayList(head);
   
   cout<<"print combinely singly and doubly link list:"<<endl;
   return 0;

